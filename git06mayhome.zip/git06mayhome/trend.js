import { bindable } from 'aurelia-framework';
import highcharts from 'highcharts';

export class TrendCustomElement {
  //chart options
  options;
  startDate;
  endDate;

  ChartData = [
    {
      TimeFrames: [
        {
          Equipments: [
            {
              Entities: [
                {
                  DataType: 5,
                  Description: {},
                  DisplayName: { '1033': 'DesignSpeed' },
                  From: '2019-02-08T06:42:17.505Z',
                  FromNano: '131940817375058394',
                  Id: '1.130.3.0.0.0',
                  Name: 'DesignSpeed_1',
                  Quality: 192,
                  To: '2019-02-14T08:33:21.006Z',
                  ToNano: '131946068010060448',
                  Type: 2,
                  UoMDisplayName: '',
                  Value: 30,
                  ValueType: 3
                },
                {
                  DataType: 5,
                  Description: {},
                  DisplayName: { '1033': 'DesignSpeed' },
                  From: '2019-02-14T08:33:21.006Z',
                  FromNano: '131946068010060448',
                  Id: '1.130.3.0.0.0',
                  Name: 'DesignSpeed_1',
                  Quality: 192,
                  To: '2019-05-06T10:30:00.000Z',
                  ToNano: '132016122000000000',
                  Type: 2,
                  UoMDisplayName: '',
                  Value: 30,
                  ValueType: 3
                }
              ],
              Id: '1.125.1.0.0.0',
              Name: 'HMI_RT_1::Plant_object_type_2_1'
            }
          ],
          From: '1601-01-01T00:00:00.000Z',
          To: '1601-01-01T00:00:00.000Z'
        }
      ]
    }
  ];

  //bindable properties
  @bindable type = 'line';
  @bindable title;
  @bindable titleY;
  @bindable subtitle;
  @bindable series;
  @bindable pointStart;

  constructor() {}

  attached() {
    this.verifyData();
    //this.series = ;
    this.buildData();
    this.loadoptions();
    highcharts.chart(this.options);
  }

  loadoptions() {
    this.options = {
      chart: {
        type: this.type,
        renderTo: this.container
      },
      title: {
        text: this.title
      },
      subtitle: {
        text: this.subtitle
      },
      xAxis: {
        type: 'datetime'
      },
      yAxis: {
        title: {
          text: this.titleY
        }
      },
      legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
      },
      plotOptions: {
        series: {
          dragDrop: {
            draggableY: true,
            // draggableX: true,
            dragMinY: 0,
            dragPrecisionY: 1
            // dragMinX: 0,
            // dragPrecisionX : 60
          },
          label: {
            connectorAllowed: false
          },
          pointStart: this.pointStart
        }
      },
      series: this.series,
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 500
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom'
              }
            }
          }
        ]
      }
    };
  }

  groupBy = (items, key) =>
    items.reduce(
      (result, item) => ({
        ...result,
        [item[key]]: [...(result[item[key]] || []), item]
      }),
      {}
    );

  verifyData() {
    if (!(this.ChartData instanceof Array)) {
      return;
    }

    if (this.ChartData.length <= 0) {
      return;
    }

    let equipments;
    let entyties;
    let entitiesCollection = [];

    if (
      !Siemens.OneOEE.Common.Utilities.elementExist(
        this.ChartData[0].TimeFrames
      )
    ) {
      return;
    }

    this.ChartData[0].TimeFrames.forEach(function(timeframe) {
      if (!Siemens.OneOEE.Common.Utilities.elementExist(timeframe.Equipments)) {
        return;
      }
      equipments = timeframe.Equipments;
      /* Extract Equipments */
      if (!(equipments instanceof Array)) {
        return;
      }

      equipments.forEach(function(equipment) {
        /* Extract Entity */
        entyties = equipment.Entities;

        if (!(entyties instanceof Array)) {
          return;
        }
        entyties.forEach(function(entity) {
          if (Siemens.OneOEE.Common.Utilities.elementExist(entity)) {
            let startUTC = new Date(entity.From);
            startUTC = Date.UTC(
              startUTC.getUTCFullYear(),
              startUTC.getUTCMonth(),
              startUTC.getUTCDate(),
              startUTC.getUTCHours(),
              startUTC.getUTCMinutes(),
              startUTC.getUTCSeconds()
            );

            let endUTC = new Date(entity.To);
            endUTC = Date.UTC(
              endUTC.getUTCFullYear(),
              endUTC.getUTCMonth(),
              endUTC.getUTCDate(),
              endUTC.getUTCHours(),
              endUTC.getUTCMinutes(),
              endUTC.getUTCSeconds()
            );

            entitiesCollection.push({
              Type: entity.Type,
              Value: entity.Value,
              Id: entity.Id,
              Name: entity.Name,
              Start: entity.From,
              startUTC: startUTC,
              startNano: entity.FromNano,
              End: entity.To,
              EndNano: entity.ToNano,
              endUTC: endUTC,
              Quality: entity.Quality,
              UuId: entity.InstanceId,
              isOpen: entity.IsOpen,
              ValueType: entity.ValueType,
              UoMDisplayName: entity.UoMDisplayName,
              DisplayName: entity.DisplayName,
              Description: entity.Description,
              equipName: equipment.Name
            });
          }
        });
      });
    });
    console.log(entitiesCollection);
    //this.ChartData = entitiesCollection;
    this.ChartData = this.groupBy(entitiesCollection, 'Id');
    console.log(this.ChartData);
  }

  buildData() {
    let filteredSeries = [];
    let tempData = {};
    for (let key of Object.keys(this.ChartData)) {
      tempData.name = this.ChartData[key][0].Name;
      tempData.data = [];
      this.ChartData[key].forEach(function(data) {
        console.log(data);
        tempData.data.push({
          name: data.Name,
          color: '#00FF00',
          y: data.Value,
          x: data.startUTC
        });

        tempData.data.push({
          name: data.Name,
          color: '#00FF00',
          y: data.Value,
          x: data.endUTC
        });
      }, this);
      filteredSeries.push(tempData);
    }
    console.log(filteredSeries);
    console.log(JSON.stringify(filteredSeries));
  }
}
