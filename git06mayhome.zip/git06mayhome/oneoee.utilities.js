Siemens.OneOEE.Common.Utilities = {
  elementExist: function(element) {
    return typeof element !== 'undefined' && element !== null;
  },

  isNumber: function(element) {
    return typeof element === 'number';
  },
  isArray: function(element) {
    return this.elementExist(element) && element instanceof Array;
  }
};
