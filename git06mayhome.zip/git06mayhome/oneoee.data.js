Siemens.OneOEE.Common.Data = {
  Types: {
    Time: 'Time',
    TimeRange: 'TimeRange',
    TimeRangeList: 'TimeRangeList',
    GroupBy: 'GroupBy',
    Array: 'Array',
    Number: 'Number',
    Color: 'Colo',
    Boolean: 'Boolean',
    String: 'String',
    Complex: 'Complex'
  },
  Server: {
    ExchangeCodes: {
      Refresh: 100,
      GetEquipments: 101,
      GetKpis: 102,
      ChangeLanguage: 109,
      ConnectionStatusChange: 110,
      LoadSettings: 150,
      AddValue: 202,
      SplitState: 203,
      SaveSettings: 250,
      ChangeValue: 302,
      ChangeTimeCategory: 303
    },
    Errors: {
      ConfInconsistent: 2147483664,
      ProperConnection: 0,
      NoConnection: 2147483670
    }
  },
  getJSON: function(file, callback, fallback) {
    xhr = new XMLHttpRequest();
    async = false;

    xhr.open('get', file, async);
    xhr.onload = function() {
      if (xhr.status === 200) {
        if (xhr.responseType === 'json') {
          callback(xhr.response);
        } else if (xhr.responseText) {
          // IE does not support responseType
          callback(JSON.parse(xhr.responseText));
        } else {
          callback('unsupported responseType');
        }
      } else {
        fallback();
      }
    };
    xhr.send();
  }
};
